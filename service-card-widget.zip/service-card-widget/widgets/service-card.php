<?php
/**
 * Service Card Widget — Elementor Widget Class
 *
 * Renders a single service card with:
 *   - Editable number badge (e.g. "01")
 *   - Editable service title
 *   - Clickable URL link (full card is the link)
 *   - Animated left accent bar on hover
 *   - Animated arrow button on hover
 *   - Full colour & typography controls in the Style tab
 *
 * @package ServiceCardWidget
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class Service_Card_Widget extends Widget_Base {

	/* ─────────────────────────────────────────────────────────────
	 * Identity
	 * ───────────────────────────────────────────────────────────── */

	public function get_name() {
		return 'scw_service_card';
	}

	public function get_title() {
		return esc_html__( 'Service Card', 'service-card-widget' );
	}

	public function get_icon() {
		return 'eicon-call-to-action';
	}

	public function get_categories() {
		return [ 'service-card-widgets', 'general' ];
	}

	public function get_keywords() {
		return [ 'service', 'card', 'transport', 'link', 'number', 'badge', 'cta' ];
	}

	/* ─────────────────────────────────────────────────────────────
	 * Controls — builds the left panel in the Elementor editor
	 * ───────────────────────────────────────────────────────────── */

	protected function register_controls() {

		/* ══════════════════════════════════════════
		 * TAB: CONTENT
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'service-card-widget' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		// Number badge
		$this->add_control(
			'service_number',
			[
				'label'       => esc_html__( 'Number Badge', 'service-card-widget' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '01',
				'placeholder' => '01',
				'label_block' => false,
				'description' => esc_html__( 'Short badge shown at the top of the card (e.g. 01, 02 …)', 'service-card-widget' ),
			]
		);

		// Service title
		$this->add_control(
			'service_title',
			[
				'label'       => esc_html__( 'Service Title', 'service-card-widget' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Corporate Airport Travel', 'service-card-widget' ),
				'placeholder' => esc_html__( 'Enter service name…', 'service-card-widget' ),
				'label_block' => true,
				'dynamic'     => [ 'active' => true ],
			]
		);

		// Link
		$this->add_control(
			'service_link',
			[
				'label'         => esc_html__( 'Link', 'service-card-widget' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://yoursite.com/service/',
				'default'       => [ 'url' => '#' ],
				'show_external' => true,
				'dynamic'       => [ 'active' => true ],
			]
		);

		// Show / hide arrow button
		$this->add_control(
			'show_arrow',
			[
				'label'        => esc_html__( 'Show Arrow Button', 'service-card-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'service-card-widget' ),
				'label_off'    => esc_html__( 'No', 'service-card-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		// Show / hide accent bar
		$this->add_control(
			'show_accent_bar',
			[
				'label'        => esc_html__( 'Show Hover Accent Bar', 'service-card-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'service-card-widget' ),
				'label_off'    => esc_html__( 'No', 'service-card-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		/* ══════════════════════════════════════════
		 * TAB: STYLE — Card
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_style_card',
			[
				'label' => esc_html__( 'Card', 'service-card-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// Normal / Hover tabs
		$this->start_controls_tabs( 'card_state_tabs' );

		// — Normal state
		$this->start_controls_tab(
			'tab_card_normal',
			[ 'label' => esc_html__( 'Normal', 'service-card-widget' ) ]
		);

		$this->add_control(
			'card_bg_color',
			[
				'label'     => esc_html__( 'Background', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111111',
				'selectors' => [
					'{{WRAPPER}} .scw-card' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .scw-card',
				'fields_options' => [
					'border' => [ 'default' => 'solid' ],
					'width'  => [ 'default' => [ 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ] ],
					'color'  => [ 'default' => '#2a2a2a' ],
				],
			]
		);

		$this->add_control(
			'card_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'service-card-widget' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [ 'top' => '6', 'right' => '6', 'bottom' => '6', 'left' => '6', 'isLinked' => true, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .scw-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'card_padding',
			[
				'label'      => esc_html__( 'Padding', 'service-card-widget' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [ 'top' => '36', 'right' => '40', 'bottom' => '36', 'left' => '40', 'isLinked' => false, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .scw-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'card_box_shadow',
				'selector' => '{{WRAPPER}} .scw-card',
			]
		);

		$this->end_controls_tab();

		// — Hover state
		$this->start_controls_tab(
			'tab_card_hover',
			[ 'label' => esc_html__( 'Hover', 'service-card-widget' ) ]
		);

		$this->add_control(
			'card_bg_color_hover',
			[
				'label'     => esc_html__( 'Background', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#161616',
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(201,168,76,0.5)',
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'card_box_shadow_hover',
				'selector' => '{{WRAPPER}} .scw-card:hover',
			]
		);

		$this->add_control(
			'card_transition_duration',
			[
				'label'     => esc_html__( 'Transition Duration (ms)', 'service-card-widget' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [ 'size' => 300 ],
				'range'     => [ 'px' => [ 'min' => 100, 'max' => 800, 'step' => 50 ] ],
				'selectors' => [
					'{{WRAPPER}} .scw-card' => 'transition-duration: {{SIZE}}ms;',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		/* ══════════════════════════════════════════
		 * TAB: STYLE — Accent Color (drives multiple elements)
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_style_accent',
			[
				'label' => esc_html__( 'Accent & Hover Colors', 'service-card-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'accent_color',
			[
				'label'     => esc_html__( 'Accent Color', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#C9A84C',
				'description' => esc_html__( 'Controls: hover accent bar, arrow fill, and number badge on hover.', 'service-card-widget' ),
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover .scw-accent'              => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .scw-card:hover .scw-arrow'               => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}} .scw-card:hover .scw-number'              => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'accent_bar_width',
			[
				'label'      => esc_html__( 'Accent Bar Width', 'service-card-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [ 'size' => 3, 'unit' => 'px' ],
				'range'      => [ 'px' => [ 'min' => 1, 'max' => 12 ] ],
				'selectors'  => [
					'{{WRAPPER}} .scw-accent' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [ 'show_accent_bar' => 'yes' ],
			]
		);

		$this->add_control(
			'accent_bar_origin',
			[
				'label'   => esc_html__( 'Bar Slides In From', 'service-card-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'bottom',
				'options' => [
					'bottom' => esc_html__( 'Bottom → Top', 'service-card-widget' ),
					'top'    => esc_html__( 'Top → Bottom', 'service-card-widget' ),
					'center' => esc_html__( 'Center', 'service-card-widget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .scw-accent' => 'transform-origin: {{VALUE}};',
				],
				'condition' => [ 'show_accent_bar' => 'yes' ],
			]
		);

		$this->end_controls_section();

		/* ══════════════════════════════════════════
		 * TAB: STYLE — Number Badge
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_style_number',
			[
				'label' => esc_html__( 'Number Badge', 'service-card-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Color (Normal)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4a3f1e',
				'selectors' => [
					'{{WRAPPER}} .scw-number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'number_typography',
				'selector' => '{{WRAPPER}} .scw-number',
				'fields_options' => [
					'font_size'      => [ 'default' => [ 'size' => '13', 'unit' => 'px' ] ],
					'font_weight'    => [ 'default' => '700' ],
					'letter_spacing' => [ 'default' => [ 'size' => '2' ] ],
					'text_transform' => [ 'default' => 'uppercase' ],
				],
			]
		);

		$this->end_controls_section();

		/* ══════════════════════════════════════════
		 * TAB: STYLE — Title
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Service Title', 'service-card-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color (Normal)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#e8e4dc',
				'selectors' => [
					'{{WRAPPER}} .scw-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_hover',
			[
				'label'     => esc_html__( 'Color (Hover)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover .scw-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .scw-title',
				'fields_options' => [
					'font_size'   => [ 'default' => [ 'size' => '22', 'unit' => 'px' ] ],
					'font_weight' => [ 'default' => '700' ],
					'line_height' => [ 'default' => [ 'size' => '1.15', 'unit' => 'em' ] ],
				],
			]
		);

		$this->add_responsive_control(
			'gap_between',
			[
				'label'      => esc_html__( 'Gap (Number → Title Row)', 'service-card-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [ 'size' => 32, 'unit' => 'px' ],
				'range'      => [ 'px' => [ 'min' => 8, 'max' => 80 ] ],
				'selectors'  => [
					'{{WRAPPER}} .scw-card' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		/* ══════════════════════════════════════════
		 * TAB: STYLE — Arrow Button
		 * ══════════════════════════════════════════ */

		$this->start_controls_section(
			'section_style_arrow',
			[
				'label'     => esc_html__( 'Arrow Button', 'service-card-widget' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [ 'show_arrow' => 'yes' ],
			]
		);

		$this->add_control(
			'arrow_size',
			[
				'label'      => esc_html__( 'Button Size', 'service-card-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [ 'size' => 44, 'unit' => 'px' ],
				'range'      => [ 'px' => [ 'min' => 28, 'max' => 80 ] ],
				'selectors'  => [
					'{{WRAPPER}} .scw-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrow_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'service-card-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [ 'size' => 16, 'unit' => 'px' ],
				'range'      => [ 'px' => [ 'min' => 8, 'max' => 40 ] ],
				'selectors'  => [
					'{{WRAPPER}} .scw-arrow svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrow_color',
			[
				'label'     => esc_html__( 'Icon Color (Normal)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#5a5550',
				'selectors' => [
					'{{WRAPPER}} .scw-arrow' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrow_color_hover',
			[
				'label'     => esc_html__( 'Icon Color (Hover)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover .scw-arrow' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrow_border_color',
			[
				'label'     => esc_html__( 'Border Color (Normal)', 'service-card-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#2a2a2a',
				'selectors' => [
					'{{WRAPPER}} .scw-arrow' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrow_rotate_hover',
			[
				'label'   => esc_html__( 'Rotate on Hover', 'service-card-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '45deg',
				'options' => [
					'0deg'   => esc_html__( 'None', 'service-card-widget' ),
					'45deg'  => esc_html__( '45°', 'service-card-widget' ),
					'90deg'  => esc_html__( '90°', 'service-card-widget' ),
					'-45deg' => esc_html__( '-45°', 'service-card-widget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .scw-card:hover .scw-arrow' => 'transform: rotate({{VALUE}});',
				],
			]
		);

		$this->end_controls_section();
	}

	/* ─────────────────────────────────────────────────────────────
	 * RENDER — front-end HTML output
	 * ───────────────────────────────────────────────────────────── */

	protected function render() {
		$settings = $this->get_settings_for_display();

		// Sanitise output values.
		$number     = esc_html( $settings['service_number'] );
		$title      = esc_html( $settings['service_title'] );
		$show_arrow = 'yes' === $settings['show_arrow'];
		$show_bar   = 'yes' === $settings['show_accent_bar'];

		// Build link attributes the Elementor way (handles target, nofollow, etc).
		$this->add_link_attributes( 'card_link', $settings['service_link'] );
		$this->add_render_attribute( 'card_link', 'class', 'scw-card' );
		$this->add_render_attribute( 'card_link', 'aria-label',
			sprintf(
				/* translators: %s: Service title */
				esc_attr__( 'Learn more about %s', 'service-card-widget' ),
				$title
			)
		);
		?>
		<a <?php echo $this->get_render_attribute_string( 'card_link' ); ?>>

			<?php if ( $show_bar ) : ?>
				<span class="scw-accent" aria-hidden="true"></span>
			<?php endif; ?>

			<span class="scw-number"><?php echo $number; ?></span>

			<span class="scw-bottom">
				<span class="scw-title"><?php echo $title; ?></span>

				<?php if ( $show_arrow ) : ?>
					<span class="scw-arrow" aria-hidden="true">
						<svg viewBox="0 0 24 24" fill="none"
							 stroke="currentColor" stroke-width="2"
							 stroke-linecap="round" stroke-linejoin="round">
							<path d="M7 17L17 7M17 7H7M17 7v10"/>
						</svg>
					</span>
				<?php endif; ?>
			</span>

		</a>
		<?php
	}

	/* ─────────────────────────────────────────────────────────────
	 * CONTENT TEMPLATE — live JS preview inside Elementor editor
	 * ───────────────────────────────────────────────────────────── */

	protected function content_template() {
		?>
		<#
		var show_arrow = settings.show_arrow === 'yes';
		var show_bar   = settings.show_accent_bar === 'yes';
		var link_url   = settings.service_link.url || '#';
		#>
		<a class="scw-card" href="{{ link_url }}" aria-label="Learn more about {{{ settings.service_title }}}">

			<# if ( show_bar ) { #>
				<span class="scw-accent" aria-hidden="true"></span>
			<# } #>

			<span class="scw-number">{{{ settings.service_number }}}</span>

			<span class="scw-bottom">
				<span class="scw-title">{{{ settings.service_title }}}</span>

				<# if ( show_arrow ) { #>
					<span class="scw-arrow" aria-hidden="true">
						<svg viewBox="0 0 24 24" fill="none"
							 stroke="currentColor" stroke-width="2"
							 stroke-linecap="round" stroke-linejoin="round">
							<path d="M7 17L17 7M17 7H7M17 7v10"/>
						</svg>
					</span>
				<# } #>
			</span>

		</a>
		<?php
	}
}
