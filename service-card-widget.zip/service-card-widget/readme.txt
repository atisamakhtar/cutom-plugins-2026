=== Service Card Widget for Elementor ===
Contributors: yourname
Tags: elementor, widget, service card, transport, custom widget
Requires at least: 5.9
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A custom Elementor widget that renders a single service card with number badge, title, link, and animated hover states.

== Description ==

**Service Card Widget** adds a professional, fully-animated service card block to your Elementor editor.

Each widget instance renders one card. Drag it multiple times into a 2- or 3-column Elementor Grid to build a complete services section — matching the dark, luxury transport design aesthetic.

= Features =

* Editable **number badge** (e.g. 01, 02, 03…)
* Editable **service title** with dynamic tag support
* Full **URL link** control with open-in-new-tab and nofollow options
* Animated **gold accent bar** that slides up on hover
* Animated **arrow button** that rotates and fills on hover
* **Accent color** picker (controls bar + arrow + number highlight simultaneously)
* Per-state background and border color controls (Normal / Hover)
* Full **Typography** group control for both number and title
* Arrow size, icon size, rotation angle — all configurable
* **Toggle** accent bar and arrow button on/off independently
* Appears in a dedicated "Service Card Widgets" panel category
* Keyboard accessible (focus-visible outline)
* Works in Elementor editor live preview

= How to use =

1. Activate the plugin
2. Open Elementor editor on any page
3. Search "Service Card" in the widget panel
4. Drag the widget into your layout
5. Fill in the Number, Title and Link in the Content tab
6. Adjust colors and typography in the Style tab
7. Repeat for each service — use an Elementor Grid (2 columns, 2px gap) to match the original design

== Installation ==

1. Upload the `service-card-widget` folder to `/wp-content/plugins/`
2. Activate via **Plugins → Installed Plugins**
3. Elementor must be installed and active

== Changelog ==

= 1.0.0 =
* Initial release
