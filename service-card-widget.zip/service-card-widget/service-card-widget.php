<?php
/**
 * Plugin Name:       Service Card Widget
 * Plugin URI:        https://yoursite.com
 * Description:       A custom Elementor widget that renders a single service card with an editable number badge, service title, link, and animated hover states. Use it multiple times in a grid to build a full services section.
 * Version:           1.0.0
 * Requires at least: 5.9
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://yoursite.com
 * License:           GPL v2 or later
 * Text Domain:       service-card-widget
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'SCW_VERSION',     '1.0.0' );
define( 'SCW_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SCW_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class — singleton pattern.
 */
final class Service_Card_Widget_Plugin {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	public function init() {
		// Bail if Elementor is not loaded.
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_elementor' ] );
			return;
		}

		// Check minimum Elementor version.
		if ( ! version_compare( ELEMENTOR_VERSION, '3.0.0', '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Register custom widget category.
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_widget_category' ] );

		// Register the widget itself.
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );

		// Enqueue front-end styles.
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );

		// Enqueue styles inside the Elementor editor too.
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_styles' ] );

		// Enqueue styles in Elementor preview iframe.
		add_action( 'elementor/preview/enqueue_styles', [ $this, 'enqueue_styles' ] );
	}

	/**
	 * Register a custom widget category so the widget is easy to find.
	 */
	public function register_widget_category( $elements_manager ) {
		$elements_manager->add_category(
			'service-card-widgets',
			[
				'title' => esc_html__( 'Service Card Widgets', 'service-card-widget' ),
				'icon'  => 'eicon-call-to-action',
			]
		);
	}

	/**
	 * Include the widget class and register it.
	 */
	public function register_widgets( $widgets_manager ) {
		require_once SCW_PLUGIN_DIR . 'widgets/service-card.php';
		$widgets_manager->register( new \Service_Card_Widget() );
	}

	/**
	 * Enqueue the widget stylesheet.
	 */
	public function enqueue_styles() {
		wp_enqueue_style(
			'service-card-widget',
			SCW_PLUGIN_URL . 'assets/service-card.css',
			[],
			SCW_VERSION
		);
	}

	/**
	 * Admin notice — Elementor not installed.
	 */
	public function admin_notice_missing_elementor() {
		$message = sprintf(
			/* translators: %s: Plugin name */
			esc_html__( '"%s" requires Elementor to be installed and activated.', 'service-card-widget' ),
			'<strong>Service Card Widget</strong>'
		);
		printf( '<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message );
	}

	/**
	 * Admin notice — Elementor version too old.
	 */
	public function admin_notice_minimum_elementor_version() {
		$message = sprintf(
			/* translators: %1$s: Plugin name, %2$s: Required version */
			esc_html__( '"%1$s" requires Elementor version %2$s or greater.', 'service-card-widget' ),
			'<strong>Service Card Widget</strong>',
			'<strong>3.0.0</strong>'
		);
		printf( '<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message );
	}
}

// Boot the plugin.
Service_Card_Widget_Plugin::instance();
